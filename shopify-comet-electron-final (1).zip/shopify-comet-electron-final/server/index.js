require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const fetch = require('node-fetch');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cookieParser());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const SHOPIFY_API_KEY = process.env.SHOPIFY_API_KEY;
const SHOPIFY_API_SECRET = process.env.SHOPIFY_API_SECRET;
const SCOPES = process.env.SHOPIFY_SCOPES || 'read_products';

if (!SHOPIFY_API_KEY || !SHOPIFY_API_SECRET) {
  console.warn('SHOPIFY_API_KEY/SECRET no configurados. Añade .env con las credenciales.');
}

app.get('/auth', (req, res) => {
  const shop = req.query.shop;
  if (!shop) return res.status(400).send('Falta parámetro `shop`');

  const state = uuidv4();
  res.cookie('shopify_auth_state', state, { httpOnly: true, sameSite: 'lax' });

  const redirectUri = `${getBaseUrl(req)}/auth/callback`;
  const installUrl = `https://${shop}/admin/oauth/authorize?client_id=${SHOPIFY_API_KEY}&scope=${SCOPES}&state=${state}&redirect_uri=${encodeURIComponent(redirectUri)}`;
  res.redirect(installUrl);
});

app.get('/auth/callback', async (req, res) => {
  const { shop, code, state } = req.query;
  const localState = req.cookies.shopify_auth_state;
  if (state !== localState) return res.status(403).send('Invalid state');

  const tokenEndpoint = `https://${shop}/admin/oauth/access_token`;
  try {
    const resp = await fetch(tokenEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: SHOPIFY_API_KEY, client_secret: SHOPIFY_API_SECRET, code })
    });
    const data = await resp.json();
    res.send(`<h2>Instalación completada</h2><pre>${JSON.stringify(data, null, 2)}</pre>`);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error intercambiando token');
  }
});

app.get('/', (req, res) => res.send('Servidor Shopify Comet OK.'));

app.listen(PORT, () => console.log(`Server corriendo en http://localhost:${PORT}`));

function getBaseUrl(req) {
  const proto = req.headers['x-forwarded-proto'] || req.protocol;
  return `${proto}://${req.get('host')}`;
}
