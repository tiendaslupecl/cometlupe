const statusEl = document.getElementById('status');
const btn = document.getElementById('connect');

async function init() {
  if (window.electronAPI) {
    const info = await window.electronAPI.getAppInfo();
    statusEl.textContent = `App: ${info.name} (${info.version})`;
  } else {
    statusEl.textContent = 'Ejecutándose en modo web / dev.';
  }
}

btn.addEventListener('click', () => {
  const oauthUrl = window.location.origin.replace('/app', '') + '/auth';
  window.open(oauthUrl, '_blank', 'width=900,height=700');
});

init();
